namespace PubQuizBuster.ActivityCreator;

partial class PQBActivityForm
{
    private System.ComponentModel.IContainer components = null!;

    private TabControl _tabs = null!;
    private TabPage _moviesTab = null!;
    private TabPage _musicTab = null!;
    private TabPage _geographyTab = null!;
    private MoviesActivityControl _moviesControl = null!;
    private MusicActivityControl _musicControl = null!;
    private GeographyActivityControl _geographyControl = null!;

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            components?.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        _tabs = new TabControl();
        _moviesTab = new TabPage();
        _moviesControl = new MoviesActivityControl();
        _musicTab = new TabPage();
        _musicControl = new MusicActivityControl();
        _geographyTab = new TabPage();
        _geographyControl = new GeographyActivityControl();
        _tabs.SuspendLayout();
        _moviesTab.SuspendLayout();
        _musicTab.SuspendLayout();
        _geographyTab.SuspendLayout();
        SuspendLayout();
        // 
        // _tabs
        // 
        _tabs.Controls.Add(_moviesTab);
        _tabs.Controls.Add(_musicTab);
        _tabs.Controls.Add(_geographyTab);
        _tabs.Dock = DockStyle.Fill;
        _tabs.Font = new Font("Segoe UI", 14.14286F);
        _tabs.Location = new Point(0, 0);
        _tabs.Name = "_tabs";
        _tabs.Padding = new Point(15, 3);
        _tabs.SelectedIndex = 0;
        _tabs.Size = new Size(1122, 530);
        _tabs.TabIndex = 0;
        // 
        // _moviesTab
        // 
        _moviesTab.Controls.Add(_moviesControl);
        _moviesTab.Location = new Point(4, 34);
        _moviesTab.Name = "_moviesTab";
        _moviesTab.Padding = new Padding(3, 3, 3, 3);
        _moviesTab.Size = new Size(1114, 492);
        _moviesTab.TabIndex = 0;
        _moviesTab.Text = "Movies";
        // 
        // _moviesControl
        // 
        _moviesControl.Dock = DockStyle.Fill;
        _moviesControl.Location = new Point(3, 3);
        _moviesControl.Name = "_moviesControl";
        _moviesControl.Size = new Size(1108, 486);
        _moviesControl.TabIndex = 0;
        _moviesControl.Load += _moviesControl_Load;
        // 
        // _musicTab
        // 
        _musicTab.Controls.Add(_musicControl);
        _musicTab.Location = new Point(4, 34);
        _musicTab.Name = "_musicTab";
        _musicTab.Padding = new Padding(3, 3, 3, 3);
        _musicTab.Size = new Size(1313, 678);
        _musicTab.TabIndex = 1;
        _musicTab.Text = "Music";
        // 
        // _musicControl
        // 
        _musicControl.Dock = DockStyle.Fill;
        _musicControl.Location = new Point(3, 3);
        _musicControl.Name = "_musicControl";
        _musicControl.Size = new Size(1307, 672);
        _musicControl.TabIndex = 0;
        // 
        // _geographyTab
        // 
        _geographyTab.Controls.Add(_geographyControl);
        _geographyTab.Font = new Font("Segoe UI", 9F);
        _geographyTab.Location = new Point(4, 34);
        _geographyTab.Name = "_geographyTab";
        _geographyTab.Padding = new Padding(3, 3, 3, 3);
        _geographyTab.Size = new Size(1313, 678);
        _geographyTab.TabIndex = 2;
        _geographyTab.Text = "Geography";
        // 
        // _geographyControl
        // 
        _geographyControl.Dock = DockStyle.Fill;
        _geographyControl.Location = new Point(3, 3);
        _geographyControl.Name = "_geographyControl";
        _geographyControl.Size = new Size(1307, 672);
        _geographyControl.TabIndex = 0;
        // 
        // PQBActivityForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1122, 530);
        Controls.Add(_tabs);
        MinimumSize = new Size(1126, 535);
        Name = "PQBActivityForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Pub Quiz Buster!";
        _tabs.ResumeLayout(false);
        _moviesTab.ResumeLayout(false);
        _musicTab.ResumeLayout(false);
        _geographyTab.ResumeLayout(false);
        ResumeLayout(false);
    }
}

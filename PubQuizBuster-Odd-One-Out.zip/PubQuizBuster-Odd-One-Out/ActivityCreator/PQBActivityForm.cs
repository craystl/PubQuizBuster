namespace PubQuizBuster.ActivityCreator;

public sealed partial class PQBActivityForm : Form
{
    public PQBActivityForm()
    {
        InitializeComponent();
    }

    private void _moviesControl_Load(object sender, EventArgs e)
    {

    }
}
